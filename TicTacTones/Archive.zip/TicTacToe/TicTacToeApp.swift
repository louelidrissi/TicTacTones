//
//  TicTacToeApp.swift
//  TicTacToe
//
//  Created by Lou El Idrissi on 1/27/25.
//

import SwiftUI

@main
struct TicTacToeSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
//            MusicPalyer()
        }
    }
}
