//
//  PlayMusic.swift
//  TicTacToe
//
//  Created by Lou El Idrissi on 1/28/25.
//

import AVFoundation
import AVKit

class AudioPlayerViewModel: ObservableObject {
  var audioPlayer: AVAudioPlayer?

  @Published var isPlaying = false
    //func timer() { }
    
    func playSound() {
        
        // pick a random song from song list
        
        // define the time interval the song will be playing
        // call random function and a time interval between 10 and 15 seconds
        // once time interval is up, stop the song
        // turn isPlaying to false

        guard let url = Bundle.main.url(forResource: "shake", withExtension: ".m4a")
        else {return}
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch let error {
            print("Error playing sound.  \(error.localizedDescription)")
        }
    

    }
    
    func pauseSound() {
            audioPlayer?.pause()
    }

/*
  func playOrPause() {
    guard let player = audioPlayer else { return }

    if player.isPlaying {
      player.pause()
      isPlaying = false
    } else {
      player.play()
      isPlaying = true
    }
  }*/
    
}
