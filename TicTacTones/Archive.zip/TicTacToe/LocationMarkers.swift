//
//  ContentView.swift
//  TestTicTacToe
//
//  Created by Lou El Idrissi on 2/3/25.
//


// look into .wave

import SwiftUI
import SwiftUIPausableAnimation

struct ContentView: View {
    //@State var isSpinning = false
    
    @StateObject var audioPlayerViewModel = AudioPlayerViewModel()
    
    @State private var angle = 0.0
    @State private var isPaused = true
     
    
    // song needs to stop within 12 seconds
     private let duration: TimeInterval = 12
     private let startAngle = 0.0
     private let endAngle = 720.0
     private var remainingDuration: RemainingDurationProvider<Double> {
       { currentAngle in
         duration * (1 - (currentAngle - startAngle) / (endAngle - startAngle))
       }
     }
     private let animation: AnimationWithDurationProvider = { duration in
       .linear(duration: duration)
     }
    
    func deg2rad(_ number: CGFloat) -> CGFloat {
        return number * .pi / 180
    }
    
    
    var body: some View {
        VStack{
            Button {
//                isPaused.toggle()
                if isPaused {
                    isPaused = false
                    audioPlayerViewModel.playSound()
//                    audioPlayerViewModel.isPlaying = true
                    
                } else {
                    isPaused = true
                    audioPlayerViewModel.pauseSound()
                }
                
//                if audioPlayerViewModel.isPlaying {
//                    //pause the music
//                    audioPlayerViewModel.pauseSound()
//                    audioPlayerViewModel.isPlaying = false
//                    
//                } else {
//                    //play
//                    audioPlayerViewModel.playSound()
//                    audioPlayerViewModel.isPlaying = true
//                }
                
            }label: {
                Text("Start Game!")
            }
        // put circular  path on a Z-stack
            ZStack{
               
                // This will be the Circular Path
                // Circle()
                //   .stroke()
                //.hidden()
                //    .frame(width: 300)
                
                GameView()
                    .frame(width: 500, height: 500)
                
                
                //every 20
                let degrees: [CGFloat] =  [20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240, 260, 280, 300, 320, 340, 360]//[36, 72, 108, 144, 180, 216, 252, 288, 324, 360]
                //ForEach(degrees) then delete once it's placed
                
                ForEach(degrees, id: \.self) { degree in
                    
                    Circle()
                        .frame(width: 55, height: 50)
                        .offset(x: cos(deg2rad(degree))*350, y: sin(deg2rad(degree))*350)
                        .rotationEffect(.degrees(angle))
                    // .rotationEffect(.degrees(isPaused ? 0: -360))
                    //.animation(.linear(duration: 5).repeatForever(autoreverses: false), value: isSpinning)
                        .pausableAnimation(binding: $angle,
                                           targetValue: endAngle,
                                           remainingDuration: remainingDuration,
                                           animation: animation,
                                           paused: $isPaused)
                        .onTapGesture(count: 1) {
                            isPaused = true
                            //fgColor = colors.randomElement()!
                        }
                }
                
            }
//            MusicPalyer()
        }
    
            
    }
}
  




#Preview {
    ContentView()
}

